<?php
$user="placeholder";		#put your loginname (should be an email address) between the quotes
$password="placeholder"; 	#put your password between the quotes
$LoadTimeout=5;				#if no dots show up on the crawler page ("....") you could set this to a lower value
$PageTimeout=600;			#maximum number of seconds the crawler is trying to go through all the pages; set higher if necessary
?>